<?php
	header("location: ../../index.php");
	die();
?>