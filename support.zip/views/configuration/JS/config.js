
function modal_element($type,$id)
{
	
}

