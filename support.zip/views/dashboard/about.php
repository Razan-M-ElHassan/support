<section class="contact">
	<div class="container">
		<div class="row gy-4">
			<div class="title">
				<h1 class="display-3 text-bold">من نحن</h1>
				<!--h5 class="lead text-body-secondary">اقراء الشروط والاحكام جيداً</h5-->
			</div>
			<h5><?php echo html_entity_decode($this->about);?></h5>
		</div>
	</div>
</section>
<script>
	var js_details		=  {'FILES':[]};
	var js_specialist 	= {};
	
</script>