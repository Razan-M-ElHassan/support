CREATE DATABASE IF NOT EXISTS `graduate`;

USE `graduate`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `grad_config`;

CREATE TABLE `grad_config` (
  `conf_user` int(5) NOT NULL DEFAULT '0',
  `conf_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `conf_val` text COLLATE utf8_unicode_ci NOT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`conf_user`,`conf_name`),
  KEY `conf_user` (`conf_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `grad_config` VALUES (0,"ADDRESS","السعودية",NULL),
(0,"DESC_INFO","نظام عرض الخريجين",NULL),
(0,"EMAIL_ADD","test@maknorsoft.com",NULL),
(0,"FACEBOOK","https://facebook.com",NULL),
(0,"INSTAGRAM","https://instagram.com",NULL),
(0,"INVESTMENT",900,NULL),
(0,"LOGIN_FOOTER","جميع الحقوق محفوظة\r\n2022\r\nبرمجة وتطوير: ماكنورسوفت",NULL),
(0,"LOGO","logo.png",NULL),
(0,"PAGING",10,NULL),
(0,"PHONE","+249900987961",NULL),
(0,"TITLE","الخرجين",NULL),
(0,"TWITTER","https://twitter.com",NULL),
(1,"EMAIL_HOST","mail.maknorsoft.com",NULL),
(1,"EMAIL_PORT",587,NULL),
(1,"EMAIL_SEND_ADD","test@maknorsoft.com",NULL),
(1,"EMAIL_SEND_PASS","passme@TEST123456",NULL),
(1,"EMAIL_SMTP_AUTH",1,NULL);


DROP TABLE IF EXISTS `grad_forget`;

CREATE TABLE `grad_forget` (
  `for_id` int(10) NOT NULL AUTO_INCREMENT,
  `for_user` int(55) NOT NULL,
  `create_at` datetime NOT NULL,
  PRIMARY KEY (`for_id`),
  KEY `for_user` (`for_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `grad_notification`;

CREATE TABLE `grad_notification` (
  `noti_id` int(11) NOT NULL AUTO_INCREMENT,
  `noti_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `noti_user` int(5) NOT NULL,
  `noti_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `noti_link` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noti_status` int(2) DEFAULT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`noti_id`),
  KEY `noti_user` (`noti_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `grad_pages`;

CREATE TABLE `grad_pages` (
  `page_id` int(10) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `page_class` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `page` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `page_description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `page_per_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'read',
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `page` (`page_class`,`page`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `grad_pages` VALUES (1,"الضبط","configuration","index","تحديث الاعدادات","تحديث"),
(2,"الصلاحيات","permission","index","الدخول لصفحة الصلاحيات","عرض"),
(3,"الصلاحيات","permission","new_group","إضافة مجموعة جديدة","إضافة"),
(4,"الصلاحيات","permission","upd_group","تحديث الصلاحيات","تحديث"),
(5,"الصلاحيات","permission","del_group","حذف صلاحية","حذف"),
(6,"النسخ الاحتياطي","backup","index","الدخول لصفحة النسخ الاحتياطي","عرض"),
(7,"النسخ الاحتياطي","backup","new_backup","إضافة نسخة احتياطية","إضافة"),
(8,"النسخ الاحتياطي","backup","get_file","تنزيل ملف نسخة احتياطية","عرض"),
(9,"النسخ الاحتياطي","backup","get_backup","استرجاع نسخة احتياطية","تحديث"),
(10,"النسخ الاحتياطي","backup","upload_backup","اضافة ملف نسخة احتياطية","إضافة"),
(11,"النسخ الاحتياطي","backup","del_backup","حذف ملف نسخة احتياطية","حذف"),
(12,"الطلاب","staff","index","الدخول لصفحة الطلاب","عرض"),
(13,"الطلاب","staff","new_staff","إضافة طالب جديد","إضافة"),
(14,"الطلاب","staff","upd_staff","تحديث بيانات الطالب","تحديث"),
(15,"الطلاب","staff","active","إيقاف وفك إيقاف الطلاب","تحديث"),
(16,"الطلاب","staff","msg_staff","ارسال رسالة للطلاب","إضافة"),
(17,"الطلاب","staff","del_file","مسح ملف مستخدم","حذف"),
(18,"انواع البيانات","item_type","index","عرض انواع البيانات الاضافية للطلاب","عرض"),
(19,"انواع البيانات","item_type","new_type","اضافة نوع بيانات","إضافة"),
(20,"انواع البيانات","item_type","upd_tyoe","تعديل بيانات نوع","تحديث"),
(21,"انواع البيانات","item_type","del_type","حذف نوع","حذف"),
(25,"انواع السيارات","car_type","new_type","اضافة نوع سيارة","insert"),
(26,"انواع السيارات","car_type","upd_type","تعديل نوع سيارة","update"),
(27,"انواع السيارات","car_type","del_type","حذف نوع سيارة","delete"),
(30,"السيارات","car","index","عرض السيارات","عرض"),
(31,"السيارات","car","new_car","إضافة سيارة جديدة","إضافة"),
(32,"السيارات","car","upd_car","تحديث سيارة","تحديث"),
(33,"السيارات","car","del_car","حذف سيارة","حذف"),
(34,"السيارات","car","active","إيقاف وفك إيقاف السيارة","تحديث"),
(35,"السيارات","car","upd_driver","تحديث بيانات رخصة السيارة","تحديث"),
(36,"السيارات","car","del_file","مسح ملف سيارة","حذف"),
(38,"الملاك","owner","index","عرض ملاك السيارات","عرض"),
(39,"الملاك","owner","new_owner","إضافة مالك جديد","إضافة"),
(40,"الملاك","owner","upd_owner","تحديث مالك","تحديث"),
(41,"الملاك","owner","del_owner","حذف مالك","حذف"),
(42,"الملاك","owner","msg_owner","ارسال رسالة للمالك","ادخال"),
(45,"شركات التأمين","insurance_co","index","عرض شركات التأمين","عرض"),
(46,"شركات التأمين","insurance_co","new_inc","إضافة شركة تأمين","إضافة"),
(47,"شركات التأمين","insurance_co","upd_inc","تحديث شركة تأمين","تحديث"),
(48,"شركات التأمين","insurance_co","del_inc","حذف شركة تأمين","حذف"),
(49,"شركات التأمين","insurance_co","msg_inc","ارسال رسالة لشركة تأمين","ادخال"),
(51,"الفحص الدوري","inspection","index","عرض الفحص الدوري","عرض"),
(52,"الفحص الدوري","inspection","new_inc","إضافة فحص","إضافة"),
(53,"الفحص الدوري","inspection","upd_inc","تحديث فحص","تحديث"),
(54,"الفحص الدوري","inspection","del_inc","حذف فحص","حذف"),
(55,"الفحص الدوري","inspection","del_file","حذف ملف فحص","حذف"),
(58,"كروت التشغيل","card","index","عرض كروت التشغيل","عرض"),
(59,"كروت التشغيل","card","new_card","إضافة كرت التشفيل","إضافة"),
(60,"كروت التشغيل","card","upd_card","تحديث كرت التشغيل","تحديث"),
(61,"كروت التشغيل","card","del_card","حذف كرت التشغيل","حذف"),
(64,"انواع الصيانة","insp_type","index","عرض انواع الصيانة","عرض"),
(65,"انواع الصيانة","insp_type","new_insp_type","إضافة انواع الصيانة","إضافة"),
(66,"انواع الصيانة","insp_type","upd_insp_type","تحديث انواع الصيانة","تحديث"),
(67,"انواع الصيانة","insp_type","del_insp_type","حذف انواع الصيانة","حذف"),
(70,"التأمين","insurance","index","عرض التأمين","عرض"),
(71,"التأمين","insurance","new_inc","إضافة تأمين","إضافة"),
(72,"التأمين","insurance","upd_inc","تحديث تأمين","تحديث"),
(73,"التأمين","insurance","del_inc","حذف تأمين","حذف"),
(74,"التأمين","insurance","del_file","حذف ملف تأمين","حذف"),
(76,"انواع المخالفات","violation_type","index","عرض انواع المخالفات","عرض"),
(77,"انواع المخالفات","violation_type","new_vio_type","إضافة انواع المخالفات","إضافة"),
(78,"انواع المخالفات","violation_type","upd_vio_type","تحديث انواع المخالفات","تحديث"),
(79,"انواع المخالفات","violation_type","del_vio_type","حذف انواع المخالفات","حذف"),
(81,"المخالفات","violation","index","عرض انواع المخالفات","عرض"),
(82,"المخالفات","violation","new_vio","إضافة المخالفات","إضافة"),
(83,"المخالفات","violation","upd_vio","تحديث المخالفات","تحديث"),
(84,"المخالفات","violation","del_vio","حذف المخالفات","حذف"),
(85,"المخالفات","violation","del_file","حذف ملف المخالفات","حذف"),
(88,"الحوادث","accident","index","عرض انواع الحوادث","عرض"),
(89,"الحوادث","accident","new_acc","إضافة الحوادث","إضافة"),
(90,"الحوادث","accident","upd_acc","تحديث الحوادث","تحديث"),
(91,"الحوادث","accident","del_acc","حذف الحوادث","حذف"),
(92,"الحوادث","accident","del_file","حذف ملف الحوادث","حذف"),
(95,"استلام وتسليم السيارات","receipt","index","عرض استلام وتسليم السيارات","عرض"),
(96,"استلام وتسليم السيارات","receipt","new_rec","إضافة استلام سيارة","إضافة"),
(97,"استلام وتسليم السيارات","receipt","upd_rec","تحديث استلام سيارة","تحديث"),
(98,"استلام وتسليم السيارات","receipt","del_rec","حذف استلام سيارة","حذف"),
(99,"استلام وتسليم السيارات","receipt","new_del","اضافة تسليم سيارة ","اضافة"),
(100,"استلام وتسليم السيارات","receipt","upd_del","تحديث بيانات تسليم السيارة","تحديث"),
(101,"استلام وتسليم السيارات","receipt","del_del","حذف تسليم السيارة","حذف"),
(102,"استلام وتسليم السيارات","receipt","del_file","مسح ملف سيارة","حذف");


DROP TABLE IF EXISTS `grad_per_group_pages`;

CREATE TABLE `grad_per_group_pages` (
  `per_group_permission` int(5) NOT NULL,
  `per_group_page` int(10) NOT NULL,
  `create_at` datetime NOT NULL,
  `create_by` int(5) NOT NULL,
  PRIMARY KEY (`per_group_permission`,`per_group_page`),
  KEY `fkey_create` (`create_by`),
  KEY `per_gr_page_pages` (`per_group_page`),
  CONSTRAINT `staff_page` FOREIGN KEY (`per_group_page`) REFERENCES `grad_pages` (`page_id`),
  CONSTRAINT `staff_permission` FOREIGN KEY (`per_group_permission`) REFERENCES `grad_permission_groups` (`per_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `grad_per_group_pages` VALUES (1,1,"2023-01-01 00:00:00",1),
(1,2,"2023-01-01 00:00:00",1),
(1,3,"2023-01-01 00:00:00",1),
(1,4,"2023-01-01 00:00:00",1),
(1,5,"2023-01-01 00:00:00",1),
(1,6,"2023-01-01 00:00:00",1),
(1,7,"2023-01-01 00:00:00",1),
(1,8,"2023-01-01 00:00:00",1),
(1,9,"2023-01-01 00:00:00",1),
(1,10,"2023-01-01 00:00:00",1),
(1,11,"2023-01-01 00:00:00",1),
(1,12,"2023-01-01 00:00:00",1),
(1,13,"2023-01-01 00:00:00",1),
(1,14,"2023-01-01 00:00:00",1),
(1,15,"2023-01-01 00:00:00",1),
(1,16,"2023-01-01 00:00:00",1),
(1,17,"2023-01-01 00:00:00",1);


DROP TABLE IF EXISTS `grad_permission_groups`;

CREATE TABLE `grad_permission_groups` (
  `per_id` int(5) NOT NULL AUTO_INCREMENT,
  `per_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `per_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `per_default_page` int(5) NOT NULL,
  `per_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `create_by` int(5) NOT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` int(5) DEFAULT NULL,
  PRIMARY KEY (`per_id`),
  KEY `fkey_create` (`create_by`),
  KEY `fkey_update` (`update_by`),
  KEY `per_default_page` (`per_default_page`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `grad_permission_groups` VALUES (1,"System Admin","ADMIN",1,"Main Permission For System Admin - No Update","2023-01-01 00:00:00",1,NULL,NULL),
(2,"طلاب","STUDENT",1,"الطلاب الذين لا يستخدمون النظام","2023-01-14 08:19:20",1,NULL,NULL);


DROP TABLE IF EXISTS `grad_staff`;

CREATE TABLE `grad_staff` (
  `staff_id` int(5) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `staff_permission` tinyint(4) NOT NULL DEFAULT '2',
  `staff_img` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'usr.png',
  `staff_phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `staff_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `staff_pass` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_val` int(10) DEFAULT NULL,
  `staff_active` tinyint(1) NOT NULL DEFAULT '1',
  `create_at` datetime NOT NULL,
  `create_by` int(5) NOT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` int(5) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  KEY `staff_permission` (`staff_permission`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `grad_staff` VALUES (1,"المدير",1,"usr.png",0900987961,"admin@admin.com","5db074ea7a3d9c0cc12409c2c92cc3625c183f6f88fbc9f0c84bbd439acb4ed1",NULL,1,"2023-03-24 00:00:00",1,NULL,NULL);


DROP TABLE IF EXISTS `item_type`;

CREATE TABLE `item_type` (
  `item_ty_id` int(4) NOT NULL AUTO_INCREMENT,
  `item_ty_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_ty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `staff_item_type`;

CREATE TABLE `staff_item_type` (
  `ity_staff` int(5) NOT NULL,
  `ity_item` int(5) NOT NULL,
  `ity_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'char',
  `ity_val` text COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `create_by` int(5) NOT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` int(5) DEFAULT NULL,
  PRIMARY KEY (`ity_staff`,`ity_item`),
  KEY `create_by` (`create_by`),
  KEY `update_by` (`update_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



SET foreign_key_checks = 1;
